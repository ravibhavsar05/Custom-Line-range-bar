import MultiSlider from '@ptomasroos/react-native-multi-slider';
import React, {useState, type PropsWithChildren} from 'react';
import {
  Dimensions,
  SafeAreaView,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';

import {Colors} from 'react-native/Libraries/NewAppScreen';
import CustomMarker from './CustomMarker';
import CustomMarkerYellow from './CustomMarkerYellow';
import CustomMarkerGreen from './CustomMarkerGreen';
import CustomMarkerRed from './CustomMarkerRed';
import CustomMarkerOrange from './CustomMarkerOrange';

const Section: React.FC<
  PropsWithChildren<{
    title: string;
  }>
> = ({children, title}) => {
  const isDarkMode = useColorScheme() === 'dark';
  return (
    <View style={styles.sectionContainer}>
      <Text
        style={[
          styles.sectionTitle,
          {
            color: isDarkMode ? Colors.white : Colors.black,
          },
        ]}>
        {title}
      </Text>
      <Text
        style={[
          styles.sectionDescription,
          {
            color: isDarkMode ? Colors.light : Colors.dark,
          },
        ]}>
        {children}
      </Text>
    </View>
  );
};

const App = () => {
  const [multiSliderValueGreen, setMultiSliderValueGreen] = useState([20]);
  const [multiSliderValueYellow, setMultiSliderValueYellow] = useState([
    20, 60,
  ]);
  const [multiSliderValueRed, setMultiSliderValueRed] = useState([60, 80]);
  const [multiSliderValueOrange, setMultiSliderValueOrange] = useState([
    80, 120,
  ]);

  const [multiSliderValueGreen2, setMultiSliderValueGreen2] = useState([20]);
  const [multiSliderValueYellow2, setMultiSliderValueYellow2] = useState([
    0, 40,
  ]);
  const [multiSliderValueRed2, setMultiSliderValueRed2] = useState([1, 20]);
  const [multiSliderValueOrange2, setMultiSliderValueOrange2] = useState([
    1, 40,
  ]);
  const [disableGreen, setDisableGreen] = useState(true);

  const multiSliderValuesChangeGreen = values => {
    // console.log('greenValues::', values[0]);
    if (values[0] <= 20) {
      console.log('greenValues 2222::', values[0]);
      setMultiSliderValueGreen(values);
    }
    // if (values[0] > 21) {
    //   setDisableGreen(false);
    // } else {
    //   setDisableGreen(true);
    // }
  };

  const multiSliderValuesChangeYellow = values => {
    setMultiSliderValueYellow(values);
  };

  const multiSliderValuesChangeRed = values => setMultiSliderValueRed(values);

  const multiSliderValuesChangeOrange = values =>
    setMultiSliderValueOrange(values);

  const multiSliderValuesChangeGreen2 = values => {
    // console.log('greenValues::', values[0]);
    if (values[0] <= 20) {
      console.log('greenValues 2222::', values[0]);
      setMultiSliderValueGreen2(values);
    }
    // if (values[0] > 21) {
    //   setDisableGreen(false);
    // } else {
    //   setDisableGreen(true);
    // }
  };

  const multiSliderValuesChangeYellow2 = values => {
    setMultiSliderValueYellow2(values);
  };

  const multiSliderValuesChangeRed2 = values => setMultiSliderValueRed2(values);

  const multiSliderValuesChangeOrange2 = values =>
    setMultiSliderValueOrange2(values);

  // const disableScroll = () => setDisable(false);

  return (
    <SafeAreaView>
      <>
        <View style={styles.mainView}>
          <Text style={styles.textColor}>Green</Text>

          <MultiSlider
            values={[multiSliderValueGreen[0]]}
            min={0}
            max={120}
            step={1}
            snapped={true}
            customMarker={CustomMarkerGreen}
            // customLabel={CustomLabel}
            trackStyle={{
              backgroundColor: 'red',
              height: 3,
            }}
            unselectedStyle={{
              backgroundColor: '#EBEBEB',
            }}
            selectedStyle={{
              backgroundColor: '#98E565',
            }}
            sliderLength={Dimensions.get('window').width - 150}
            onValuesChange={multiSliderValuesChangeGreen}
            // enabledOne={disableGreen}
          />
        </View>

        <View style={styles.mainView}>
          <Text style={styles.textColor}>Yellow</Text>

          <MultiSlider
            values={[multiSliderValueYellow[0], multiSliderValueYellow[1]]}
            min={1}
            max={120}
            step={1}
            allowOverlap
            snapped
            isMarkersSeparated={true}
            // customMarker={CustomMarker}
            customMarkerRight={CustomMarkerYellow}
            customMarkerLeft={CustomMarkerGreen}
            trackStyle={{
              backgroundColor: 'red',
              height: 3,
            }}
            unselectedStyle={{
              backgroundColor: '#EBEBEB',
            }}
            selectedStyle={{
              backgroundColor: '#FFEF5C',
            }}
            sliderLength={Dimensions.get('window').width - 150}
            onValuesChange={multiSliderValuesChangeYellow}
            enabledOne={false}
          />
        </View>

        <View style={styles.mainView}>
          <Text style={styles.textColor}>Red</Text>

          <MultiSlider
            values={[multiSliderValueRed[0], multiSliderValueRed[1]]}
            min={1}
            max={120}
            step={1}
            allowOverlap
            snapped
            isMarkersSeparated={true}
            // customMarker={CustomMarker}
            customMarkerRight={CustomMarkerRed}
            customMarkerLeft={CustomMarkerYellow}
            trackStyle={{
              backgroundColor: 'red',
              height: 3,
            }}
            unselectedStyle={{
              backgroundColor: '#EBEBEB',
            }}
            selectedStyle={{
              backgroundColor: '#E05164',
            }}
            sliderLength={Dimensions.get('window').width - 150}
            onValuesChange={multiSliderValuesChangeRed}
            enabledOne={false}
          />
        </View>

        <View style={styles.mainView}>
          <Text style={styles.textColor}>Orange</Text>

          <MultiSlider
            values={[multiSliderValueOrange[0], multiSliderValueOrange[1]]}
            min={0}
            max={120}
            step={1}
            allowOverlap
            snapped
            isMarkersSeparated={true}
            // customMarker={CustomMarker}
            customMarkerRight={CustomMarkerOrange}
            customMarkerLeft={CustomMarkerRed}
            trackStyle={{
              backgroundColor: 'red',
              height: 3,
            }}
            unselectedStyle={{
              backgroundColor: '#EBEBEB',
            }}
            selectedStyle={{
              backgroundColor: '#FF8F66',
            }}
            sliderLength={Dimensions.get('window').width - 150}
            onValuesChange={multiSliderValuesChangeOrange}
            enabledOne={false}
          />
        </View>

        <View style={styles.mainView2}>
          <Text style={styles.textColor2}>Green</Text>

          {/* <View style={{marginStart: '11%'}}> */}
          <View style={{marginStart: '11%'}}>
            <MultiSlider
              values={[multiSliderValueGreen2[0]]}
              min={0}
              max={20}
              step={1}
              snapped={true}
              customMarker={CustomMarkerGreen}
              // customLabel={CustomLabel}
              trackStyle={{
                backgroundColor: 'red',
                height: 3,
                // marginLeft: '50%',
              }}
              unselectedStyle={{
                backgroundColor: '#EBEBEB',
              }}
              selectedStyle={{
                backgroundColor: '#98E565',
              }}
              sliderLength={Dimensions.get('window').width / 8.9}
              // sliderLength={80}
              onValuesChange={multiSliderValuesChangeGreen2}
              // enabledOne={disableGreen}
            />
          </View>

          <View
            style={{
              flex: 3,
              borderWidth: 1.5,
              borderColor: '#EBEBEB',
              // marginStart: '11%',
            }}
          />
        </View>

        <View style={styles.mainView}>
          <Text style={styles.textColor2}>Yellow</Text>

          <View
            style={{
              borderWidth: 1.5,
              borderColor: '#EBEBEB',
              marginLeft: '10%',
              flex: 1,
              justifyContent: 'center',
              // alignItems: 'center',
              // backgroundColor: 'green',
            }}>
            <View
              style={{
                position: 'absolute',
                zIndex: 100,
                // backgroundColor: 'red',
                // width: '40%',
                marginStart: '17%',
              }}>
              <MultiSlider
                values={[
                  multiSliderValueYellow2[0],
                  multiSliderValueYellow2[1],
                ]}
                min={1}
                max={40}
                step={1}
                allowOverlap
                snapped
                isMarkersSeparated={true}
                // customMarker={CustomMarker}
                customMarkerRight={CustomMarkerYellow}
                customMarkerLeft={CustomMarkerGreen}
                trackStyle={{
                  backgroundColor: 'red',
                  height: 3,
                }}
                unselectedStyle={{
                  backgroundColor: '#EBEBEB',
                }}
                selectedStyle={{
                  backgroundColor: '#FFEF5C',
                }}
                // sliderLength={Dimensions.get('window').width / 1.6}
                sliderLength={90}
                onValuesChange={multiSliderValuesChangeYellow2}
                enabledOne={false}
              />
            </View>
          </View>
        </View>

        <View style={styles.mainView}>
          <Text style={styles.textColor2}>Red</Text>
          <View
            style={{
              borderWidth: 1.5,
              borderColor: '#EBEBEB',
              marginLeft: '17%',
              flex: 1,
              justifyContent: 'center',
            }}>
            <View
              style={{
                position: 'absolute',
                zIndex: 100,
                marginStart: '50%',
              }}>
              <MultiSlider
                values={[multiSliderValueRed2[0], multiSliderValueRed2[1]]}
                min={1}
                max={20}
                step={1}
                allowOverlap
                snapped
                isMarkersSeparated={true}
                // customMarker={CustomMarker}
                customMarkerRight={CustomMarkerRed}
                customMarkerLeft={CustomMarkerYellow}
                trackStyle={{
                  backgroundColor: 'red',
                  height: 3,
                }}
                unselectedStyle={{
                  backgroundColor: '#EBEBEB',
                }}
                selectedStyle={{
                  backgroundColor: '#E05164',
                }}
                sliderLength={45}
                onValuesChange={multiSliderValuesChangeRed2}
                enabledOne={false}
              />
            </View>
          </View>
        </View>

        <View style={styles.mainView}>
          <Text style={styles.textColor2}>Orange</Text>
          <View
            style={{
              borderWidth: 1.5,
              borderColor: '#EBEBEB',
              marginLeft: '10%',
              flex: 1,
              justifyContent: 'center',
            }}>
            <View
              style={{
                position: 'absolute',
                zIndex: 100,

                marginStart: '67%',
              }}>
              <MultiSlider
                values={[
                  multiSliderValueOrange2[0],
                  multiSliderValueOrange2[1],
                ]}
                min={1}
                max={40}
                step={1}
                allowOverlap
                snapped
                isMarkersSeparated={true}
                customMarkerRight={CustomMarkerOrange}
                customMarkerLeft={CustomMarkerRed}
                trackStyle={{
                  backgroundColor: 'red',
                  height: 3,
                }}
                unselectedStyle={{
                  backgroundColor: '#EBEBEB',
                }}
                selectedStyle={{
                  backgroundColor: '#FF8F66',
                }}
                sliderLength={90}
                onValuesChange={multiSliderValuesChangeOrange2}
                enabledOne={false}
              />
            </View>
          </View>
        </View>
      </>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mainView: {
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: '5%',
    width: '90%',
    flexDirection: 'row',
  },
  mainView2: {
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: '20%',
    width: '90%',
    flexDirection: 'row',
  },
  textColor: {
    fontSize: 20,
    color: 'black',
    marginLeft: '5%',
  },
  textColor2: {
    fontSize: 20,
    color: 'red',
    marginLeft: '5%',
  },
});

export default App;
